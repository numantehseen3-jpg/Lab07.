
const express = require("express");
const fs = require("fs");

const app = express();
const PORT = 3000;

app.use(express.json());

const data = fs.readFileSync("students.json", "utf8");
const students = JSON.parse(data);

// Get all students
app.get("/students", (req, res) => {
    res.status(200).json(students);
});

// Filter students by department
app.get("/students/department/:department", (req, res) => {
    const department = req.params.department.toLowerCase();

    const result = students.filter(
        student =>
            student.department.toLowerCase() === department
    );

    res.status(200).json(result);
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
